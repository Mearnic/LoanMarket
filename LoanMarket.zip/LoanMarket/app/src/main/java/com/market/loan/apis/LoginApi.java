package com.market.loan.apis;

import android.annotation.SuppressLint;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.market.loan.bean.LoginResult;
import com.market.loan.constant.Apis;
import com.market.loan.http.HttpRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginApi {

}
