package com.market.loan.core;

import com.market.loan.bean.ConfigResult;
import com.market.loan.bean.UserResult;

public class ConfigCache {
    public static ConfigResult configResult = new ConfigResult();
    public static UserResult userResult = new UserResult();
    public static String token = "";
    public static String amount = "";
}
