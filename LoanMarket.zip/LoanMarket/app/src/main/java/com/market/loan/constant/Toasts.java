package com.market.loan.constant;

public final class Toasts {

    private Toasts(){}

    public final static String AGREE_CHECK_BOX = "Please read and agree the terms.";
    public final static String CONTENT_IS_NOT_EMPTY = "Please write message.";
    public final static String WAIT_TIME = "Please wait some time.";
}
