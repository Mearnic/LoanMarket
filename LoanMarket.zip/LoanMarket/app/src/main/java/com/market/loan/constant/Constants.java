package com.market.loan.constant;

/**
 * third part properties
 */
public final class Constants {
    public final static String DOMAIN = "http://test-api.hqcashmart.com";

    public final static String ADID = "";
    public final static String GPS_ADID = "";
    public final static int MAX_SMS_CODE_TIME = 60000;





}
